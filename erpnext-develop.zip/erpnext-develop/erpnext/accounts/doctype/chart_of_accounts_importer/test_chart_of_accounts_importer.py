# Copyright (c) 2019, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt
import unittest

from frappe.tests import IntegrationTestCase


class TestChartofAccountsImporter(IntegrationTestCase):
	pass
