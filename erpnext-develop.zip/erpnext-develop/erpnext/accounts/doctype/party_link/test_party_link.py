# Copyright (c) 2021, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt
# import frappe
import unittest

from frappe.tests import IntegrationTestCase


class TestPartyLink(IntegrationTestCase):
	pass
