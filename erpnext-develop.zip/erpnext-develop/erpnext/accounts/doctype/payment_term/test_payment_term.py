# Copyright (c) 2017, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt
import unittest

from frappe.tests import IntegrationTestCase


class TestPaymentTerm(IntegrationTestCase):
	pass
