doc_events = {
    "Sales Invoice": {
        "on_submit": "distributor_portal.events.sales_invoice.on_submit"
    }
}