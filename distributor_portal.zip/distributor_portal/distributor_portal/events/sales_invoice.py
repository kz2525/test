def on_submit(doc, method):
    # You can extend this function to tag invoices with distributor info
    frappe.msgprint("Sales Invoice submitted for Distributor Portal")