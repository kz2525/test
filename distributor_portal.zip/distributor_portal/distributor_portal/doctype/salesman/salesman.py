import frappe
from frappe.model.document import Document

class Salesman(Document):
    pass